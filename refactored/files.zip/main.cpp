/*
 * ESP32 Reptile Thermostat with PID Control
 * Version: 1.4.0 - Modular Refactor (Phase 3 Complete)
 * Last Updated: January 10, 2026
 * 
 * Phase 2: Network stack modularized
 * Phase 3: Control & logic modularized (PID, State, Scheduler)
 */

#include <Arduino.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <RBDdimmer.h>
#include <TFT_eSPI.h>
#include <SPI.h>

// Include network modules (Phase 2)
#include "wifi_manager.h"
#include "mqtt_manager.h"
#include "web_server.h"

// Include control modules (Phase 3)
#include "pid_controller.h"
#include "system_state.h"
#include "scheduler.h"

// Pin definitions
#define ONE_WIRE_BUS 4
#define DIMMER_PIN 5
#define ZEROCROSS_PIN 27

// Firmware version
#define FIRMWARE_VERSION "1.4.0"

// Hardware objects
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature sensors(&oneWire);
dimmerLamp dimmer(DIMMER_PIN, ZEROCROSS_PIN);
TFT_eSPI tft = TFT_eSPI();

// TFT display state
int currentScreen = 0;  // 0=main, 1=settings, 2=simple
bool displayNeedsUpdate = true;

// Timing
unsigned long lastTempRead = 0;
unsigned long lastPidTime = 0;
unsigned long lastMqttPublish = 0;
unsigned long lastDisplayUpdate = 0;
unsigned long bootTime = 0;

// Forward declarations
void updatePID(void);
void readTemperature(void);
void initDisplay(void);
void drawMainScreen(void);
void updateDisplay(void);
void checkTouch(void);
void onMQTTSetpoint(const char* topic, const char* message);
void onMQTTMode(const char* topic, const char* message);
void onWebControl(float temp, const char* mode);
void onWebRestart(void);
void addLog(const char* message);

void setup() {
    Serial.begin(115200);
    bootTime = millis();
    
    Serial.println("=== ESP32 Reptile Thermostat v" FIRMWARE_VERSION " ===");
    addLog("System boot - v" FIRMWARE_VERSION);
    
    // Initialize TFT display
    initDisplay();
    
    // Initialize hardware
    sensors.begin();
    dimmer.begin(NORMAL_MODE, ON);
    dimmer.setPower(0);
    
    // Initialize system state (loads preferences)
    state_init();
    addLog("System state initialized");
    
    // Load PID gains and initialize controller
    PIDGains_t gains;
    state_load_pid_gains(&gains);
    pid_init(gains.Kp, gains.Ki, gains.Kd);
    addLog("PID controller initialized");
    
    // Initialize scheduler
    scheduler_init();
    addLog("Scheduler initialized");
    
    // Get device name for network setup
    char deviceName[32];
    state_get_device_name(deviceName, sizeof(deviceName));
    
    // Initialize WiFi
    wifi_init();
    addLog("WiFi initialized");
    
    // Setup mDNS if connected
    if (!wifi_is_ap_mode()) {
        wifi_setup_mdns(deviceName);
        
        // Setup NTP time
        configTime(0, 0, "pool.ntp.org", "time.nist.gov");
        addLog("Time sync started");
        
        // Initialize MQTT
        mqtt_init();
        mqtt_set_setpoint_callback(onMQTTSetpoint);
        mqtt_set_mode_callback(onMQTTMode);
        addLog("MQTT initialized");
    }
    
    // Initialize web server
    webserver_init();
    webserver_set_device_info(deviceName, FIRMWARE_VERSION);
    webserver_set_control_callback(onWebControl);
    webserver_set_restart_callback(onWebRestart);
    webserver_set_schedule_data(scheduler_is_enabled(), 
                               scheduler_get_slot_count(), 
                               scheduler_get_slots());
    addLog("Web server started");
    
    // Draw initial screen
    drawMainScreen();
    
    Serial.println("=== Initialization Complete ===");
    Serial.print("Free heap: ");
    Serial.println(ESP.getFreeHeap());
}

void loop() {
    // Get current system state
    SystemState_t* state = state_get();
    
    // Network tasks
    wifi_task();
    
    if (!wifi_is_ap_mode()) {
        mqtt_task();
        scheduler_task();  // Check schedule
    }
    
    webserver_task();
    
    // Read temperature (every 2s)
    if (millis() - lastTempRead >= 2000) {
        readTemperature();
        lastTempRead = millis();
    }
    
    // Update PID control (every 1s)
    if (millis() - lastPidTime >= 1000) {
        // Compute power based on mode
        int power = 0;
        
        if (strcmp(state->mode, MODE_AUTO) == 0) {
            power = pid_compute(state->currentTemp, state->targetTemp);
        } else if (strcmp(state->mode, MODE_ON) == 0) {
            power = 100;
        } else {  // MODE_OFF
            power = 0;
            pid_reset();
        }
        
        // Update state
        state_set_power(power);
        state_set_heating(power > 0);
        
        // Control dimmer
        dimmer.setPower(power);
        
        lastPidTime = millis();
    }
    
    // Update TFT display (every 500ms)
    if (millis() - lastDisplayUpdate >= 500) {
        if (currentScreen == 0) {
            updateDisplay();
        }
        lastDisplayUpdate = millis();
    }
    
    // Check touch input
    checkTouch();
    
    // Update webserver state
    webserver_set_state(state->currentTemp, state->targetTemp, state->heating, 
                       state->mode, state->power);
    webserver_set_network_status(!wifi_is_ap_mode(), wifi_is_ap_mode(), 
                                 wifi_get_ssid(), wifi_get_ip_address());
    
    // Publish MQTT status (every 30s)
    if (!wifi_is_ap_mode() && mqtt_is_connected()) {
        if (millis() - lastMqttPublish >= 30000) {
            mqtt_publish_status(state->currentTemp, state->targetTemp, 
                               state->heating, state->mode, state->power);
            lastMqttPublish = millis();
            
            // Send HA discovery once
            static bool discoveryDone = false;
            if (!discoveryDone) {
                char devName[32];
                state_get_device_name(devName, sizeof(devName));
                mqtt_send_ha_discovery(devName, "reptile_thermostat_01");
                discoveryDone = true;
            }
        }
    }
}

// ===== CALLBACK FUNCTIONS =====

void onMQTTSetpoint(const char* topic, const char* message) {
    float newTarget = atof(message);
    if (newTarget >= 15.0 && newTarget <= 45.0) {
        state_set_target_temp(newTarget, true);
        pid_reset();
        
        char log[64];
        snprintf(log, sizeof(log), "Target: %.1f°C (MQTT)", newTarget);
        addLog(log);
        
        displayNeedsUpdate = true;
    }
}

void onMQTTMode(const char* topic, const char* message) {
    String newMode = String(message);
    if (newMode == "auto" || newMode == "off" || newMode == "heat") {
        const char* mode = (newMode == "heat") ? MODE_ON : newMode.c_str();
        state_set_mode(mode, true);
        pid_reset();
        
        char log[64];
        snprintf(log, sizeof(log), "Mode: %s (MQTT)", mode);
        addLog(log);
        
        displayNeedsUpdate = true;
    }
}

void onWebControl(float temp, const char* newMode) {
    state_set_target_temp(temp, true);
    state_set_mode(newMode, true);
    pid_reset();
    
    char log[64];
    snprintf(log, sizeof(log), "Control: %.1f°C, %s (Web)", temp, newMode);
    addLog(log);
    
    displayNeedsUpdate = true;
    
    // Publish to MQTT
    SystemState_t* state = state_get();
    if (mqtt_is_connected()) {
        mqtt_publish_status(state->currentTemp, state->targetTemp, 
                           state->heating, state->mode, state->power);
    }
}

void onWebRestart(void) {
    addLog("Restart requested");
    ESP.restart();
}

// ===== HARDWARE FUNCTIONS =====

void readTemperature(void) {
    sensors.requestTemperatures();
    float temp = sensors.getTempCByIndex(0);
    
    if (temp != DEVICE_DISCONNECTED_C && temp > -50 && temp < 100) {
        SystemState_t* state = state_get();
        if (abs(temp - state->currentTemp) > 0.1) {
            state_set_current_temp(temp);
            displayNeedsUpdate = true;
        }
    } else {
        static unsigned long lastError = 0;
        if (millis() - lastError > 60000) {
            addLog("Temp sensor error!");
            lastError = millis();
        }
    }
}

// ===== TFT DISPLAY FUNCTIONS (MINIMAL) =====

void initDisplay(void) {
    tft.init();
    tft.setRotation(1);
    tft.fillScreen(TFT_BLACK);
    
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(50, 110);
    tft.println("Reptile Thermostat");
    tft.setCursor(80, 140);
    tft.setTextSize(1);
    tft.println("Initializing...");
    
    delay(2000);
}

void drawMainScreen(void) {
    tft.fillScreen(TFT_BLACK);
    
    // Header
    tft.fillRect(0, 0, 320, 35, TFT_DARKGREEN);
    tft.setTextColor(TFT_WHITE, TFT_DARKGREEN);
    tft.setTextSize(2);
    tft.setCursor(5, 10);
    
    char deviceName[32];
    state_get_device_name(deviceName, sizeof(deviceName));
    
    // Truncate if too long
    if (strlen(deviceName) > 13) {
        deviceName[13] = '\0';
    }
    tft.print(deviceName);
    
    // WiFi/MQTT status
    tft.setTextSize(1);
    tft.setCursor(245, 8);
    if (wifi_is_ap_mode()) {
        tft.setTextColor(TFT_ORANGE, TFT_DARKGREEN);
        tft.print("AP");
    } else if (WiFi.status() == WL_CONNECTED) {
        tft.setTextColor(TFT_GREEN, TFT_DARKGREEN);
        tft.print("WiFi");
    }
    
    tft.setCursor(245, 20);
    if (mqtt_is_connected()) {
        tft.setTextColor(TFT_GREEN, TFT_DARKGREEN);
        tft.print("MQTT");
    } else {
        tft.setTextColor(TFT_DARKGREY, TFT_DARKGREEN);
        tft.print("----");
    }
    
    // Labels
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, 50);
    tft.print("Current:");
    tft.setCursor(10, 120);
    tft.print("Target:");
    
    // Draw button boxes
    // MINUS button
    tft.fillRect(210, 115, 45, 45, TFT_DARKGREY);
    tft.drawRect(210, 115, 45, 45, TFT_WHITE);
    
    // PLUS button
    tft.fillRect(265, 115, 45, 45, TFT_DARKGREY);
    tft.drawRect(265, 115, 45, 45, TFT_WHITE);
    
    // SIMPLE VIEW button (bottom left)
    tft.fillRect(10, 185, 70, 50, TFT_PURPLE);
    tft.drawRect(10, 185, 70, 50, TFT_WHITE);
    
    // SETTINGS button (bottom right)
    tft.fillRect(240, 185, 70, 50, TFT_NAVY);
    tft.drawRect(240, 185, 70, 50, TFT_WHITE);
    
    // Button labels
    tft.setTextSize(4);
    tft.setTextColor(TFT_WHITE, TFT_DARKGREY);
    tft.setCursor(222, 123);
    tft.print("-");
    tft.setCursor(277, 123);
    tft.print("+");
    
    // Simple button label
    tft.setTextSize(1);
    tft.setTextColor(TFT_WHITE, TFT_PURPLE);
    tft.setCursor(17, 205);
    tft.print("SIMPLE");
    
    // Settings button label
    tft.setTextColor(TFT_WHITE, TFT_NAVY);
    tft.setCursor(248, 202);
    tft.print("SETUP");
    
    displayNeedsUpdate = true;
}

void updateDisplay(void) {
    if (!displayNeedsUpdate) return;
    
    SystemState_t* state = state_get();
    
    // Current temp
    tft.fillRect(120, 45, 180, 40, TFT_BLACK);
    tft.setTextSize(4);
    tft.setCursor(120, 50);
    tft.setTextColor(state->heating ? TFT_RED : TFT_CYAN, TFT_BLACK);
    
    char tempStr[10];
    sprintf(tempStr, "%.1fC", state->currentTemp);
    tft.print(tempStr);
    
    // Target temp (moved left, away from buttons)
    tft.fillRect(120, 115, 80, 35, TFT_BLACK);
    tft.setTextSize(3);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK);
    tft.setCursor(120, 120);
    sprintf(tempStr, "%.1fC", state->targetTemp);
    tft.print(tempStr);
    
    // Status (between buttons, smaller area)
    tft.fillRect(90, 185, 140, 50, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(90, 195);
    
    if (strcmp(state->mode, MODE_OFF) == 0) {
        tft.setTextColor(TFT_LIGHTGREY, TFT_BLACK);
        tft.print("OFF");
    } else if (state->heating) {
        tft.setTextColor(TFT_RED, TFT_BLACK);
        tft.print("HEAT");
        tft.setTextSize(1);
        tft.setCursor(90, 215);
        tft.print(state->power);
        tft.print("%");
    } else {
        tft.setTextColor(TFT_GREEN, TFT_BLACK);
        tft.print("IDLE");
    }
    
    displayNeedsUpdate = false;
}

void checkTouch(void) {
    uint16_t t_x = 0, t_y = 0;
    bool pressed = tft.getTouch(&t_x, &t_y);
    
    if (pressed) {
        Serial.print("Touch: x=");
        Serial.print(t_x);
        Serial.print(", y=");
        Serial.println(t_y);
        
        int screen_x = map(t_y, 0, 320, 0, 320);
        int screen_y = map(t_x, 0, 240, 0, 240);
        
        SystemState_t* state = state_get();
        
        // Check if minus button pressed
        if (screen_x >= 100 && screen_x <= 150 && screen_y >= 100 && screen_y <= 140) {
            Serial.println("MINUS button pressed");
            float newTarget = state->targetTemp - 0.5;
            if (newTarget < 15.0) newTarget = 15.0;
            
            state_set_target_temp(newTarget, true);
            pid_reset();
            displayNeedsUpdate = true;
            
            if (mqtt_is_connected()) {
                mqtt_publish_status(state->currentTemp, state->targetTemp, 
                                   state->heating, state->mode, state->power);
            }
            
            delay(300);
        }
        // Check if plus button pressed
        else if (screen_x >= 100 && screen_x <= 150 && screen_y >= 40 && screen_y <= 80) {
            Serial.println("PLUS button pressed");
            float newTarget = state->targetTemp + 0.5;
            if (newTarget > 45.0) newTarget = 45.0;
            
            state_set_target_temp(newTarget, true);
            pid_reset();
            displayNeedsUpdate = true;
            
            if (mqtt_is_connected()) {
                mqtt_publish_status(state->currentTemp, state->targetTemp,
                                   state->heating, state->mode, state->power);
            }
            
            delay(300);
        }
    }
}

// ===== LOGGING =====

void addLog(const char* message) {
    unsigned long uptime = (millis() - bootTime) / 1000;
    unsigned long hours = uptime / 3600;
    unsigned long minutes = (uptime % 3600) / 60;
    unsigned long seconds = uptime % 60;
    
    char timestamp[20];
    sprintf(timestamp, "[%02lu:%02lu:%02lu]", hours, minutes, seconds);
    
    String logMsg = String(timestamp) + " " + String(message);
    webserver_add_log(logMsg.c_str());
    
    Serial.println(logMsg);
}
