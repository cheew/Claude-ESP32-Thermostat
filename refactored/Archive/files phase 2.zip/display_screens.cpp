#include "hardware/display.h"
#include "config.h"

// This file contains the screen drawing functions for the Display class
// Split into separate file for better organization

// ============================================
// MAIN SCREEN DRAWING
// ============================================

void Display::drawMainScreen(const DisplayState& state, bool fullRedraw) {
    if (fullRedraw) {
        m_tft.fillScreen(TFT_BLACK);
        
        // Header bar
        m_tft.fillRect(0, 0, 320, 35, TFT_DARKGREEN);
        m_tft.setTextColor(TFT_WHITE, TFT_DARKGREEN);
        m_tft.setTextSize(2);
        m_tft.setCursor(5, 10);
        
        // Device name (truncate if too long)
        String name = state.deviceName;
        if (name.length() > 13) {
            name = name.substring(0, 13);
        }
        m_tft.print(name);
        
        // WiFi status icon
        m_tft.setTextSize(1);
        m_tft.setCursor(245, 8);
        if (state.wifiConnected) {
            m_tft.setTextColor(TFT_GREEN, TFT_DARKGREEN);
            m_tft.print("WiFi");
        } else if (state.apMode) {
            m_tft.setTextColor(TFT_ORANGE, TFT_DARKGREEN);
            m_tft.print("AP");
        } else {
            m_tft.setTextColor(TFT_RED, TFT_DARKGREEN);
            m_tft.print("NoWiFi");
        }
        
        // MQTT status
        m_tft.setCursor(245, 20);
        if (state.mqttConnected) {
            m_tft.setTextColor(TFT_GREEN, TFT_DARKGREEN);
            m_tft.print("MQTT");
        } else {
            m_tft.setTextColor(TFT_DARKGREY, TFT_DARKGREEN);
            m_tft.print("----");
        }
        
        // Labels
        m_tft.setTextColor(TFT_WHITE, TFT_BLACK);
        m_tft.setTextSize(2);
        m_tft.setCursor(10, 50);
        m_tft.print("Current:");
        m_tft.setCursor(10, 120);
        m_tft.print("Target:");
        
        // Draw buttons
        // MINUS button
        m_tft.fillRect(210, 115, 45, 45, TFT_DARKGREY);
        m_tft.drawRect(210, 115, 45, 45, TFT_WHITE);
        
        // PLUS button
        m_tft.fillRect(265, 115, 45, 45, TFT_DARKGREY);
        m_tft.drawRect(265, 115, 45, 45, TFT_WHITE);
        
        // SIMPLE VIEW button
        m_tft.fillRect(10, 185, 70, 50, TFT_PURPLE);
        m_tft.drawRect(10, 185, 70, 50, TFT_WHITE);
        
        // SETTINGS button
        m_tft.fillRect(240, 185, 70, 50, TFT_NAVY);
        m_tft.drawRect(240, 185, 70, 50, TFT_WHITE);
        
        // Button labels
        m_tft.setTextSize(4);
        m_tft.setTextColor(TFT_WHITE, TFT_DARKGREY);
        m_tft.setCursor(222, 123);
        m_tft.print("-");
        m_tft.setCursor(277, 123);
        m_tft.print("+");
        
        m_tft.setTextSize(1);
        m_tft.setTextColor(TFT_WHITE, TFT_PURPLE);
        m_tft.setCursor(17, 205);
        m_tft.print("SIMPLE");
        
        m_tft.setTextColor(TFT_WHITE, TFT_NAVY);
        m_tft.setCursor(248, 202);
        m_tft.print("SETUP");
    }
    
    // Update dynamic values
    // Current Temperature
    m_tft.fillRect(120, 45, 180, 40, TFT_BLACK);
    m_tft.setTextSize(4);
    m_tft.setCursor(120, 50);
    
    if (state.heating) {
        m_tft.setTextColor(TFT_RED, TFT_BLACK);
    } else {
        m_tft.setTextColor(TFT_CYAN, TFT_BLACK);
    }
    
    char tempStr[10];
    sprintf(tempStr, "%.1fC", state.currentTemp);
    m_tft.print(tempStr);
    
    // Target Temperature
    m_tft.fillRect(120, 115, 80, 35, TFT_BLACK);
    m_tft.setTextSize(3);
    m_tft.setTextColor(TFT_YELLOW, TFT_BLACK);
    m_tft.setCursor(120, 120);
    sprintf(tempStr, "%.1fC", state.targetTemp);
    m_tft.print(tempStr);
    
    // Status
    m_tft.fillRect(90, 185, 140, 50, TFT_BLACK);
    m_tft.setTextSize(2);
    m_tft.setCursor(90, 195);
    
    if (state.mode == "off") {
        m_tft.setTextColor(TFT_LIGHTGREY, TFT_BLACK);
        m_tft.print("OFF");
    } else if (state.heating) {
        m_tft.setTextColor(TFT_RED, TFT_BLACK);
        m_tft.print("HEAT");
        m_tft.setTextSize(1);
        m_tft.setCursor(90, 215);
        m_tft.print(state.powerOutput);
        m_tft.print("%");
    } else {
        m_tft.setTextColor(TFT_GREEN, TFT_BLACK);
        m_tft.print("IDLE");
    }
}

// ============================================
// SETTINGS SCREEN DRAWING
// ============================================

void Display::drawSettingsScreen(const DisplayState& state, bool fullRedraw) {
    if (!fullRedraw) return;  // Settings screen is static
    
    m_tft.fillScreen(TFT_BLACK);
    
    // Header
    m_tft.fillRect(0, 0, 320, 35, TFT_DARKGREEN);
    m_tft.setTextColor(TFT_WHITE, TFT_DARKGREEN);
    m_tft.setTextSize(2);
    m_tft.setCursor(5, 10);
    m_tft.print("Settings");
    
    // Back button
    m_tft.fillRect(250, 5, 60, 25, TFT_NAVY);
    m_tft.drawRect(250, 5, 60, 25, TFT_WHITE);
    m_tft.setTextSize(1);
    m_tft.setCursor(265, 13);
    m_tft.print("BACK");
    
    // Device Name
    m_tft.setTextColor(TFT_CYAN, TFT_BLACK);
    m_tft.setTextSize(2);
    m_tft.setCursor(10, 50);
    m_tft.print("Device Name:");
    
    m_tft.setTextColor(TFT_WHITE, TFT_BLACK);
    m_tft.setCursor(10, 75);
    m_tft.print(state.deviceName);
    
    m_tft.setTextSize(1);
    m_tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    m_tft.setCursor(10, 95);
    m_tft.print("(Change via web)");
    
    // Mode Selection
    m_tft.setTextColor(TFT_CYAN, TFT_BLACK);
    m_tft.setTextSize(2);
    m_tft.setCursor(10, 120);
    m_tft.print("Mode:");
    
    int yPos = 145;
    
    // AUTO button
    if (state.mode == "auto") {
        m_tft.fillRect(10, yPos, 90, 40, TFT_DARKGREEN);
        m_tft.drawRect(10, yPos, 90, 40, TFT_GREEN);
        m_tft.setTextColor(TFT_WHITE, TFT_DARKGREEN);
    } else {
        m_tft.fillRect(10, yPos, 90, 40, TFT_DARKGREY);
        m_tft.drawRect(10, yPos, 90, 40, TFT_WHITE);
        m_tft.setTextColor(TFT_WHITE, TFT_DARKGREY);
    }
    m_tft.setTextSize(2);
    m_tft.setCursor(25, 157);
    m_tft.print("AUTO");
    
    // ON button
    if (state.mode == "on") {
        m_tft.fillRect(110, yPos, 90, 40, TFT_MAROON);
        m_tft.drawRect(110, yPos, 90, 40, TFT_RED);
        m_tft.setTextColor(TFT_WHITE, TFT_MAROON);
    } else {
        m_tft.fillRect(110, yPos, 90, 40, TFT_DARKGREY);
        m_tft.drawRect(110, yPos, 90, 40, TFT_WHITE);
        m_tft.setTextColor(TFT_WHITE, TFT_DARKGREY);
    }
    m_tft.setCursor(125, 157);
    m_tft.print("ON");
    
    // OFF button
    if (state.mode == "off") {
        m_tft.fillRect(210, yPos, 90, 40, TFT_NAVY);
        m_tft.drawRect(210, yPos, 90, 40, TFT_BLUE);
        m_tft.setTextColor(TFT_WHITE, TFT_NAVY);
    } else {
        m_tft.fillRect(210, yPos, 90, 40, TFT_DARKGREY);
        m_tft.drawRect(210, yPos, 90, 40, TFT_WHITE);
        m_tft.setTextColor(TFT_WHITE, TFT_DARKGREY);
    }
    m_tft.setCursor(230, 157);
    m_tft.print("OFF");
    
    // Info section
    m_tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    m_tft.setTextSize(1);
    m_tft.setCursor(10, 200);
    m_tft.print("FW: ");
    m_tft.print(FIRMWARE_VERSION);
}

// ============================================
// SIMPLE SCREEN DRAWING
// ============================================

void Display::drawSimpleScreen(const DisplayState& state, bool fullRedraw) {
    if (fullRedraw) {
        m_tft.fillScreen(TFT_BLACK);
        
        // Header
        m_tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
        m_tft.setTextSize(1);
        m_tft.setCursor(10, 10);
        m_tft.print(state.deviceName);
        
        m_tft.setCursor(160, 10);
        m_tft.print("Tap to exit");
    }
    
    // Clear temperature area
    m_tft.fillRect(0, 30, 320, 150, TFT_BLACK);
    
    // Color based on heating state
    if (state.heating) {
        m_tft.setTextColor(TFT_RED, TFT_BLACK);
    } else {
        m_tft.setTextColor(TFT_CYAN, TFT_BLACK);
    }
    
    // Giant temperature
    char tempStr[10];
    sprintf(tempStr, "%.1f", state.currentTemp);
    
    m_tft.setTextSize(14);
    m_tft.setCursor(10, 50);
    m_tft.print(tempStr);
    
    m_tft.setTextSize(10);
    m_tft.print("C");
    
    // Bottom info
    m_tft.fillRect(0, 180, 320, 60, TFT_BLACK);
    m_tft.setTextSize(3);
    m_tft.setTextColor(TFT_YELLOW, TFT_BLACK);
    m_tft.setCursor(10, 190);
    m_tft.print("Target: ");
    m_tft.print(state.targetTemp, 1);
    m_tft.print("C");
    
    // Status
    m_tft.setTextSize(2);
    m_tft.setCursor(10, 215);
    if (state.mode == "off") {
        m_tft.setTextColor(TFT_LIGHTGREY, TFT_BLACK);
        m_tft.print("OFF");
    } else if (state.heating) {
        m_tft.setTextColor(TFT_RED, TFT_BLACK);
        m_tft.print("HEATING ");
        m_tft.print(state.powerOutput);
        m_tft.print("%");
    } else {
        m_tft.setTextColor(TFT_GREEN, TFT_BLACK);
        m_tft.print("IDLE");
    }
}
